#include "pch.h"
#include "VertexGenerator.h"
#include <iostream>


float * VertexGenerator::generateVertieces()
{
	float * vertices=new float[1];
	/*
	Zadanie 1 (1 pkt):
		- zaimplementowa� metod�, kt�ra polega na stworzeniu regularnej siatki wierzcho�k�w
		  w p�aszczy�nie xz pomi�dzy zadanymi warto�ciami brzegowymi i z zadanym skokiem.
		  y ustawi� na 0. Wierzcho�ek ma mie� dwa atrybuty: pozycj� (3D) i kolor (RGBA).
		  Ustawi� odpowiednie warto�ci: size (ilo�� wierzcho�k�w), dim - wymiarowo�� wierzcho�ka, count - size*dim
	*/
		return vertices;
}

VertexGenerator::VertexGenerator()
{
	

}


VertexGenerator::~VertexGenerator()
{
}
